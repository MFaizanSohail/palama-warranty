<?php
if (! defined('ABSPATH')) {
  exit;
}

class Warranty_Form
{

  public function __construct()
  {
    add_shortcode('warranty_form', [$this, 'render_form']);
    add_action('wp_enqueue_scripts', [$this, 'enqueue_frontend_assets']);
    add_action('admin_post_pwr_submit_form', [$this, 'process_form']);
    add_action('admin_post_nopriv_pwr_submit_form', [$this, 'process_form']);
  }

  public function enqueue_frontend_assets()
  {

    wp_enqueue_style('wr-frontend-css', WR_PLUGIN_URL . 'assets/css/frontend.css', [], '1.0');
    // Enqueue jQuery UI datepicker.
    wp_enqueue_script('wr-frontend-js', WR_PLUGIN_URL . 'assets/js/frontend.js', ['jquery', 'jquery-ui-datepicker'], '1.0', true);
    wp_enqueue_style('jquery-ui-theme', 'https://code.jquery.com/ui/1.13.2/themes/smoothness/jquery-ui.css');
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css');
  }

  public function render_form()
  {
    ob_start();
    $warranty_number = $this->get_posted_value('warranty_number');
    $message = $this->get_message();
?>
    <div class="wr-container">
      <form id="wr-form" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post" enctype="multipart/form-data" novalidate>
        <input type="hidden" name="action" value="pwr_submit_form">
        <?php wp_nonce_field('pwr_form_nonce', 'pwr_nonce'); ?>

        <h2 class="wr-form-title">Register Your Palama Watch</h2>

        <div class="wr-form-row">
          <div class="wr-form-group">
            <input type="text" name="first_name" placeholder="First Name"
              value="<?php echo esc_attr($this->get_posted_value('first_name')); ?>" required>
          </div>
          <div class="wr-form-group">
            <input type="text" name="last_name" placeholder="Last Name"
              value="<?php echo esc_attr($this->get_posted_value('last_name')); ?>" required>
          </div>
        </div>

        <div class="wr-form-row">
          <div class="wr-form-group">
            <input type="email" name="email" placeholder="Email"
              value="<?php echo esc_attr($this->get_posted_value('email')); ?>" required>
          </div>

          <div class="wr-form-group">
            <input type="text" name="warranty_number" placeholder="Warranty Number (0001 - 1000)"
              value="<?php echo esc_attr($warranty_number); ?>"
              pattern="\d{4}" maxlength="4" required>
          </div>
        </div>

        <div class="wr-form-row">
          <div class="wr-form-group">
            <?php if (class_exists('WooCommerce')) :
              $countries = WC()->countries->get_countries();
              $selected_country = $this->get_posted_value('country');
            ?>
              <select name="country" required>
                <option value="">Select your country</option>
                <?php foreach ($countries as $code => $name) : ?>
                  <option value="<?php echo esc_attr($name); ?>" <?php selected($selected_country, $name); ?>>
                    <?php echo esc_html($name); ?>
                  </option>
                <?php endforeach; ?>
              </select>
            <?php else : ?>
              <input type="text" name="country" placeholder="Country" required>
            <?php endif; ?>
          </div>

          <div class="wr-form-group datepicker-icon-group">
            <input type="text" name="purchase_date" id="wr_purchase_date" autocomplete="off" placeholder="dd/mm/yyyy" required>
            <span class="calendar-icon fa-solid fa-calendar-days"></span>
          </div>
        </div>

        <h3 class="wr-label">Watch Model</h3>
        <div class="wr-radio-group">
          <?php
          $models = ['SLIM42 BAND', 'SLIDE SET', 'SLIM38 TRANSPARENCY', 'IRON', 'ROTOMESH'];
          foreach ($models as $model) :
            $checked = $this->get_posted_value('product_model') === $model ? 'checked' : '';
          ?>
            <label>
              <input type="radio" name="product_model" value="<?php echo esc_attr($model); ?>" <?php echo $checked; ?>>
              <?php echo esc_html($model); ?>
            </label>
          <?php endforeach; ?>
        </div>

        <h5 class="wr-label">Upload photo of your warranty card (Front & Back)</h5>
        <div class="wr-form-group">
          <input type="file" name="warranty_file" required>
        </div>

        <div class="wr-form-group g-recaptcha" data-sitekey="6LfqMn8rAAAAAP4N8GdCLevW39yxfm2Z_yphx-z-"></div>

        <div class="wr-checkbox-group">
          <label>
            <input type="checkbox" name="consent" value="1" required>
            I agree to the privacy policy
          </label>
        </div>

        <button type="submit" class="wr-submit-btn">Register</button>
      </form>

      <div id="wr-popup" class="wr-popup hidden">
        <div class="wr-popup-content">
          <span class="wr-popup-close">&times;</span>
          <p id="wr-popup-message"></p>
        </div>
      </div>
    </div>
<?php
    return ob_get_clean();
  }



  public function process_form()
  {
    if (! isset($_POST['pwr_nonce']) || ! wp_verify_nonce($_POST['pwr_nonce'], 'pwr_form_nonce')) {
      wp_die('Security check failed', 'Error', ['response' => 403]);
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'warranty_cards';

    // Validate fields (simplified example)
    $required = [
      'first_name'       => 'First Name',
      'last_name'        => 'Last Name',
      'email'            => 'Email',
      'purchase_date'    => 'Purchase Date',
      'product_model'    => 'Product Model',
      'country'          => 'Country',
      'warranty_number'  => 'Warranty Number',
    ];

    $errors = [];
    $data   = [];

    foreach ($required as $field => $name) {
      if (empty($_POST[$field])) {
        $errors[] = "$name is required";
      }
      $data[$field] = sanitize_text_field($_POST[$field] ?? '');
    }

    if (! is_email($data['email'])) {
      $errors[] = 'Please enter a valid email address';
    }

    $data['product_model'] = sanitize_text_field($_POST['product_model'] ?? '');

    if (! preg_match('/^\d{4}-\d{2}-\d{2}$/', $data['purchase_date'])) {
      $errors[] = 'Invalid purchase date format';
    }

    // Validate file upload (example)
    $file = $_FILES['warranty_file'] ?? null;
    if (! $file || $file['error'] !== UPLOAD_ERR_OK) {
      $errors[] = 'Warranty file is required';
    }

    // Check consent
    if (empty($_POST['consent'])) {
      $errors[] = 'You must agree to the privacy policy';
    }

    // Warranty number range check
    $warranty_number = $_POST['warranty_number'] ?? '';
    if (!preg_match('/^\d{4}$/', $warranty_number)) {
      $errors[] = 'Warranty number must be 4 digits (e.g., 0001)';
    } else {
      $number = (int) $warranty_number;
      if ($number < 1 || $number > 1000) {
        $errors[] = 'Warranty number must be between 0001 and 1000.';
      } else {
        $data['warranty_number'] = $warranty_number; // retain 0001 format
        $existing = $wpdb->get_var($wpdb->prepare(
          "SELECT COUNT(*) FROM $table_name WHERE warranty_number = %s",
          $warranty_number
        ));
        if ($existing > 0) {
          $errors[] = 'Warranty number already registered.';
        }
      }
    }


    $recaptcha_secret = '6LfqMn8rAAAAAE04tKOjyXobuwYX-5xYCzX5jWha';
    $recaptcha_response = $_POST['g-recaptcha-response'] ?? '';

    $recaptcha_verified = false;

    if (!empty($recaptcha_response)) {
      $verify_response = wp_remote_post('https://www.google.com/recaptcha/api/siteverify', [
        'body' => [
          'secret' => $recaptcha_secret,
          'response' => $recaptcha_response,
          'remoteip' => $_SERVER['REMOTE_ADDR'],
        ],
      ]);

      $response_body = wp_remote_retrieve_body($verify_response);
      $result = json_decode($response_body, true);

      if (!empty($result['success']) && $result['success'] === true) {
        $recaptcha_verified = true;
      }
    }

    if (!$recaptcha_verified) {
      $errors[] = 'reCAPTCHA verification failed. Please try again.';
    }


    if (! empty($errors)) {
      $error_query = [
        'pwr_status'  => 'error',
        'pwr_message' => urlencode(implode('|', $errors)),
        'pwr_fields'  => urlencode(json_encode($_POST))
      ];
      wp_redirect(add_query_arg($error_query, wp_get_referer()));
      exit;
    }

    // Handle file upload
    if (! function_exists('wp_handle_upload')) {
      require_once(ABSPATH . 'wp-admin/includes/file.php');
    }
    $uploaded_file = wp_handle_upload($file, [
      'test_form' => false,
      'mimes'     => [
        'jpg'  => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'png'  => 'image/png',
        'pdf'  => 'application/pdf'
      ]
    ]);
    if (isset($uploaded_file['error'])) {
      wp_redirect(add_query_arg([
        'pwr_status'  => 'error',
        'pwr_message' => urlencode('File upload error: ' . $uploaded_file['error'])
      ], wp_get_referer()));
      exit;
    }
    $data['file_url'] = $uploaded_file['url'];
    $data['warranty_number'] = sanitize_text_field($_POST['warranty_number'] ?? '');

    $qr_content = sprintf(
      "Warranty|Number: %s|Name: %s %s",
      $data['warranty_number'],
      sanitize_text_field($data['first_name']),
      sanitize_text_field($data['last_name'])
    );
    $data['qr_code_url'] = 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=' . urlencode($qr_content);

    error_log('Form data about to be saved: ' . print_r($data, true));
    $result = $wpdb->insert($table_name, $data);

    if (! $result) {
      error_log('DB Error: ' . $wpdb->last_error);
      error_log('Failed Query: ' . $wpdb->last_query);
      error_log('Submitted Data: ' . print_r($data, true));

      wp_redirect(add_query_arg([
        'pwr_status'  => 'error',
        'pwr_message' => urlencode('Database error: Could not save registration')
      ], wp_get_referer()));
      exit;
    }

    // Send confirmation email via admin class or a helper (you could refactor this too)
    Warranty_Admin::send_confirmation_email($data);

    wp_redirect(add_query_arg([
      'pwr_status'  => 'success',
      'pwr_message' => urlencode('Thank you for register your palama warranty')
    ], wp_get_referer()));

    exit;
  }

  private function get_message()
  {
    if (! isset($_GET['pwr_status']) || ! isset($_GET['pwr_message'])) {
      return false;
    }
    return [
      'type' => sanitize_text_field($_GET['pwr_status']),
      'text' => wp_kses_post(urldecode($_GET['pwr_message']))
    ];
  }

  private function get_posted_value($field)
  {
    static $posted_data = null;
    if (null === $posted_data) {
      $posted_data = [];
      if (isset($_GET['pwr_fields'])) {
        $posted_data = json_decode(urldecode($_GET['pwr_fields']), true);
        $posted_data = is_array($posted_data) ? $posted_data : [];
      }
    }
    return $posted_data[$field] ?? '';
  }
}

// Initialize the form logic.
new Warranty_Form();
