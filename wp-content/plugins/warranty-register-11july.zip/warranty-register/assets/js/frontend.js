// (function ($) {
//   $(document).ready(function () {
//     // Initialize datepicker for purchase date field
//     $("#wr_purchase_date").datepicker({
//       dateFormat: "dd-mm-yy",
//       changeMonth: true,
//       changeYear: true,
//       yearRange: "2000:+10",
//     });

//     // Client-side form validation
//     $("#wr-form").on("submit", function (e) {
//       let isValid = true;
//       const $form = $(this);
//       const requiredFields = [
//         "first_name",
//         "last_name",
//         "email",
//         "purchase_date",
//         "country",
//       ];
//       const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

//       const params = new URLSearchParams(window.location.search);
//       const status = params.get("pwr_status");
//       const message = params.get("pwr_message");

//       if (status && message) {
//         const $popup = $("#wr-popup");
//         const $popupMsg = $("#wr-popup-message");
//         $popup
//           .removeClass("hidden")
//           .addClass(status === "success" ? "success" : "error");
//         $popupMsg.text(decodeURIComponent(message.replace(/\+/g, " ")));

//         setTimeout(() => {
//           $popup.addClass("hidden");
//         }, 5000);
//       }

//       // Clear previous errors
//       $form.find(".wr-error").removeClass("wr-error");

//       // Validate input fields
//       requiredFields.forEach(function (field) {
//         const $field = $form.find('[name="' + field + '"]');
//         if (!$field.val()) {
//           $field.addClass("wr-error");
//           isValid = false;
//         }
//         if (
//           field === "email" &&
//           $field.val() &&
//           !emailRegex.test($field.val())
//         ) {
//           $field.addClass("wr-error");
//           isValid = false;
//         }
//       });

//       // Validate radio group
//       if ($form.find('input[name="product_model"]:checked').length === 0) {
//         $form
//           .find('input[name="product_model"]')
//           .first()
//           .closest(".wr-radio-group")
//           .addClass("wr-error");
//         isValid = false;
//       }

//       // Validate file upload
//       if (!$form.find('input[type="file"]').val()) {
//         $form.find('input[type="file"]').addClass("wr-error");
//         isValid = false;
//       }

//       // Validate checkbox
//       if (!$form.find('input[name="consent"]').is(":checked")) {
//         $form
//           .find('input[name="consent"]')
//           .closest(".wr-checkbox-group")
//           .addClass("wr-error");
//         isValid = false;
//       }

//       if (!isValid) {
//         e.preventDefault();
//         $("html, body").animate(
//           {
//             scrollTop: $form.offset().top - 50,
//           },
//           500
//         );
//       }
//     });

//     const $warranty = $form.find('[name="warranty_number"]');
//     const warrantyVal = $warranty.val();
//     if (
//       !/^\d{4}$/.test(warrantyVal) ||
//       parseInt(warrantyVal) < 1 ||
//       parseInt(warrantyVal) > 1000
//     ) {
//       $warranty.addClass("wr-error");
//       isValid = false;
//     }

//     $(".calendar-icon").on("click", function () {
//       $(this).siblings("input").focus(); // Triggers jQuery UI datepicker
//     });

//     // Manual popup close
//     $(".wr-popup-close").on("click", function () {
//       $("#wr-popup").addClass("hidden");
//     });
//   });
// })(jQuery);




(function ($) {
  $(document).ready(function () {
    const $form = $("#wr-form");

    // Initialize datepicker for purchase date field
    $("#wr_purchase_date").datepicker({
      dateFormat: "yy-mm-dd",
      changeMonth: true,
      changeYear: true,
      yearRange: "2000:+10",
    });

    // Trigger datepicker on calendar icon click
    $(".calendar-icon").on("click", function () {
      $(this).siblings("input").focus();
    });

    // On input: allow only numbers up to 4 digits
    $form.find('[name="warranty_number"]').on("input", function () {
      let value = $(this).val().replace(/\D/g, "");
      if (value.length > 4) value = value.slice(0, 4); 
      $(this).val(value); // Set cleaned value
    });

    // On blur: pad to 4 digits with leading zeros
    $form.find('[name="warranty_number"]').on("blur", function () {
      let value = $(this).val();
      if (value.length > 0 && value.length <= 4) {
        $(this).val(value.padStart(4, "0"));
      }
    });

    // Show popup (success or error) from URL
    function showPopupFromURL() {
      const params = new URLSearchParams(window.location.search);
      const status = params.get("pwr_status");
      const message = params.get("pwr_message");

      if (status && message) {
        const decodedMsg = decodeURIComponent(message.replace(/\+/g, " "));
        const formattedMsg = decodedMsg.split("|").join("<br>");

        const $popup = $("#wr-popup");
        const $popupMsg = $("#wr-popup-message");

        $popup
          .removeClass("hidden success error")
          .addClass(status === "success" ? "success" : "error");
        $popupMsg.html(formattedMsg);

        setTimeout(() => {
          $popup.addClass("hidden");
        }, 6000);
      }
    }

    // Delay popup display until after DOM load and scroll
    setTimeout(() => {
      showPopupFromURL();
    }, 300);

    // Manual popup close
    $(".wr-popup-close").on("click", function () {
      $("#wr-popup").addClass("hidden");
    });

    // Client-side form validation
    $form.on("submit", function (e) {
      let isValid = true;
      const requiredFields = [
        "first_name",
        "last_name",
        "email",
        "purchase_date",
        "country",
      ];
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

      // Reset error classes
      $form.find(".wr-error").removeClass("wr-error");

      requiredFields.forEach(function (field) {
        const $field = $form.find('[name="' + field + '"]');
        if (!$field.val()) {
          $field.addClass("wr-error");
          isValid = false;
        }
        if (
          field === "email" &&
          $field.val() &&
          !emailRegex.test($field.val())
        ) {
          $field.addClass("wr-error");
          isValid = false;
        }
      });

      const $radio = $form.find('input[name="product_model"]');
      if ($radio.filter(":checked").length === 0) {
        $radio.first().closest(".wr-radio-group").addClass("wr-error");
        isValid = false;
      }

      const $file = $form.find('input[type="file"]');
      if (!$file.val()) {
        $file.addClass("wr-error");
        isValid = false;
      }

      const $checkbox = $form.find('input[name="consent"]');
      if (!$checkbox.is(":checked")) {
        $checkbox.closest(".wr-checkbox-group").addClass("wr-error");
        isValid = false;
      }

      const $warranty = $form.find('[name="warranty_number"]');
      const warrantyVal = $warranty.val();
      if (
        !/^\d{4}$/.test(warrantyVal) ||
        parseInt(warrantyVal) < 1 ||
        parseInt(warrantyVal) > 1000
      ) {
        $warranty.addClass("wr-error");
        isValid = false;
      }

      if (!isValid) {
        e.preventDefault();
        $("html, body").animate(
          {
            scrollTop: $form.offset().top - 50,
          },
          400
        );
      }
    });
  });
})(jQuery);
